from django.apps import AppConfig


class RtlhAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rtlh_app'
